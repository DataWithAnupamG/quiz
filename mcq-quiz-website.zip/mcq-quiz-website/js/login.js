// async function handleLogin() {
//   const role = document.getElementById('role').value;
//   const username = document.getElementById('username').value.trim();
//   const password = document.getElementById('password').value.trim();
//   const errorMsg = document.getElementById('error-msg');

//   const jsonFile = role === 'admin' ? 'admin.json' : 'students.json';

//   try {
//     const res = await fetch(jsonFile);
//     const data = await res.json();

//     const user = data.find(u => u.username === username && u.password === password);

//     if (user) {
//       localStorage.setItem('user', JSON.stringify({ ...user, role }));
//       window.location.href = role === 'admin' ? 'admin.html' : 'quiz.html';
//     } else {
//       errorMsg.textContent = 'Invalid credentials!';
//     }
//   } catch (err) {
//     errorMsg.textContent = 'Error loading user data.';
//     console.error(err);
//   }
// }

async function handleLogin() {
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  const errorMsg = document.getElementById('error-msg');

  const jsonFile = 'students.json'; // Only one JSON file

  try {
    const res = await fetch(jsonFile);
    const data = await res.json();

    const user = data.find(u => u.username === username && u.password === password);

    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
      window.location.href = 'quiz.html'; // Redirect to quiz page for all users
    } else {
      errorMsg.textContent = 'Invalid credentials!';
    }
  } catch (err) {
    errorMsg.textContent = 'Error loading user data.';
    console.error(err);
  }
}
