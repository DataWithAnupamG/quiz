// quiz.js

let currentQuestion = 0;
let score = 0;
let quizData = [];
let selectedAnswers = {};
let timerDuration = 10 * 60; // 10 minutes
let timerInterval = null;

// Load questions from external JSON file
fetch('data/questions.json')
  .then(response => response.json())
  .then(data => {
    quizData = shuffleArray(data);
    showQuestion();
    startTimer(timerDuration);
  });

// Shuffle questions
function shuffleArray(array) {
  return array.sort(() => Math.random() - 0.5);
}

// Timer setup
function startTimer(seconds) {
  let timeLeft = seconds;
  timerInterval = setInterval(() => {
    let min = Math.floor(timeLeft / 60);
    let sec = timeLeft % 60;
    document.getElementById('timer').textContent = `⏰ Time Left: ${min}:${sec.toString().padStart(2, '0')}`;
    if (--timeLeft < 0) {
      clearInterval(timerInterval);
      submitQuiz();
    }
  }, 1000);
}

// Show current question
function showQuestion() {
  const q = quizData[currentQuestion];
  document.getElementById('question-text').textContent = q.question;
  document.getElementById('question-count').textContent = `Question: ${currentQuestion + 1}/${quizData.length}`;
  const optionsList = document.getElementById('options-list');
  optionsList.innerHTML = '';

  q.options.forEach((opt, index) => {
    const li = document.createElement('li');
    li.textContent = opt;
    li.onclick = () => selectOption(index, li);
    if (selectedAnswers[currentQuestion] !== undefined && selectedAnswers[currentQuestion] === index) {
      li.style.backgroundColor = '#d3eaff';
    }
    optionsList.appendChild(li);
  });

  document.getElementById('explanation').classList.add('hidden');
  document.getElementById('explanation').textContent = '';
}

// Select answer
function selectOption(index, liElement) {
  selectedAnswers[currentQuestion] = index;
  const allOptions = document.querySelectorAll('#options-list li');
  allOptions.forEach(li => li.style.backgroundColor = '');
  liElement.style.backgroundColor = '#d3eaff';
}

// Previous question
function previousQuestion() {
  if (currentQuestion > 0) {
    currentQuestion--;
    showQuestion();
  } else {
    alert("This is the first question.");
    showQuestion();
  }
}


// Next question
function nextQuestion() {
  if (currentQuestion < quizData.length - 1) {
    currentQuestion++;
    showQuestion();
  } else {
    alert("End of quiz. Submit your answers.");
  }
}

// Skip question
function skipQuestion() {
  currentQuestion++;
  if (currentQuestion >= quizData.length) currentQuestion = 0;
  showQuestion();
}

// // Mark for review (for future expansion)
// function markReview() {
//   alert("Marked for review (feature under development).");
// }

// Answered and Marked for Review: These answers are usually considered for evaluation, unless you go back and change your mind or remove the mark for review status before the quiz ends.
function markReview() {
  const currentAnswer = selectedAnswers[currentQuestion];
  if (currentAnswer !== undefined) {
    alert(`Question ${currentQuestion + 1} marked for review.`);
  } else {
    alert(`No answer selected for question ${currentQuestion + 1}.`);
  }
}

// Submit Quiz
function submitQuiz() {
  clearInterval(timerInterval);
  let correctCount = 0;

  quizData.forEach((q, i) => {
    if (selectedAnswers[i] === q.correctIndex) {
      correctCount++;
    }
  });

  score = correctCount;

  // Show result
  const percent = Math.round((score / quizData.length) * 100);
  const message = `
    🎉 Quiz Completed!
    ✅ Correct: ${score}
    ❌ Wrong: ${quizData.length - score}
    📊 Score: ${percent}%
  `;
  alert(message);
  // Optionally save to localStorage or send to backend
  localStorage.setItem('lastScore', percent);
  window.location.href = 'result.html';
}
